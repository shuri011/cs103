# Final Project

### Step 1a: Planning 
#### Identify the information in the file your program will read

Describe (all) the information that is available. Be sure to note any surprising or unusual features. (For example, some information sources have missing data, which may be blank or flagged using values like -99, NaN, or something else.)

<font color="blue">
The available iniformation includes: 
    
    
+ **Country/Territory Name and Code**: The dataset contains records from 204 countries or territories, each identified by both name and a country code.
    
+ **Year**: The year the mortality data was recorded, ranging from 1990 to 2019. This data is reported by researchers at the Institute of Health Metrics and Evaluation (IHME) and the Disease Burden Unit at the World Health Organization (WHO).
    
+ **Causes of Death**: The dataset includes the number of deaths for 29 different causes, covering all age groups worldwide. Examples of causes include Meningitis, Cardiovascular Diseases, Malaria, and Alzheimer's Disease.</font>

### Step 1b: Planning 
#### Brainstorm ideas for what your program will produce
#### Select the idea you will build on for subsequent steps

You must brainstorm at least two ideas for graphs or charts that your program could produce and choose the one that you'd like to work on. You can choose between a line chart, histogram, bar chart, scatterplot, or pie chart.

If you would like to change your project idea from what was described in the proposal, you will need to get permission from your project TA. This is intended to help ensure that your new project idea will meet the requirements of the project. Please see the project proposal for things to be aware of when communicating with your project TA.

<font color="blue">
First idea: (I will do the first one in this project)
    
1. Given the type of cause of death, we want to find the top 5 of the average number of deaths from causes of death (1990 - 2019).

2. Plot the top 5 average numbers of deaths for the type of cause of death between 1990 and 2019.

3. Using a bar graph, plot the cause of death (x axes) vs the average number of deaths (y axes).
    
---------------------------------------------------------------------------------------------------    
Second idea:
    
1. Given a type of cause of death, we want to find the rate of change in the numberof death by cause of death. We use the data in 2019 as a base year.
    
2. Plot the rate of change per cause of death in the country between 1990 and 2019.
    
3. Plot the year (x axes) vs the rate of change (y axes) using a line chart.
</font>

### Step 1c: Planning 
#### Write or draw examples of what your program will produce

You must include an image that shows what your chart or plot will look like. You can insert an image by uploading it into Jupyter via drag and drop and then dragging and dropping it from the sidebar to this cell. Make sure your image is a .png file.

<font color="blue">![download.png](attachment:dab219cd-6ae1-4a95-a95b-31ca15ccecba.png)</font>

### Step 2a: Building
#### Document which information you will represent in your data definitions

Before you design data definitions in the code cell below, you must explicitly document here which information in the file you chose to represent and why that information is crucial to the chart or graph that you'll produce when you complete step 2c.

<font color="blue">
For this project, I chose to represent the following information from the dataset:

- **Year**: Represents the year the data was recorded (1990-2019). It is crucial for calculating the average deaths over the time period.
- **Cause of Death columns** (29 types): Each column represents the number of deaths from a specific cause. These are essential for computing the average deaths and comparing across different causes in the bar graph.

This information is necessary because my graph will visualize the average number of deaths per cause of death over time, helping to identify the most significant global health challenges.
</font>

#### Design data definitions


```python
from cs103 import *
from typing import NamedTuple, List
import csv
from enum import Enum
##################
# Data Definitions

CauseType = Enum("CauseType", ["MENINGITIS", "ALZHEIMER_DISEASE_AND_DEMENTIAS", "PARKINSON", "NUTRITIONAL_DEFICIENCIES", "MALARIA",
                               "DROWNING", "INTERPERSONAL_VIOLENCE", "MATERNAL_DISORDERS", "DRUG", "TUBERCULOSIS", "CARDIOVASCULAR_DISEASES", 
                               "LOWER_RESPIRATORY_INFECTIONS", "NEONATAL_DISORDER", "ALCOHOL_USE_DISORDERS", "SELF_HARM", "EXPOSURE_TO_FORCES_OF_NATURE", 
                               "DIARRHEAL_DISEASES", "ENVIRONMENTAL_HEAT_AND_COLD", "NEOPLASMS", "CONFLICT_AND_TERRORISM", "DIABETES_MELLITUS", "CHRONIC_KINDNEY_DISEASE",
                               "POISONINGS", "PROTEIN_ENERGY_MALNUTRITIONI", "CHRONIC_RESPIRATORY", "CIRRHOOSIS_AND_OTHER_CHRONIC_IVER_DISEASES",
                               "DIGESTIVE_DISEASES", "FIRE_HEAT_HOT", "ACUTE_HEPATITIS", "UNKNOWN"])
# interp. This is the type of cause of death, representing one of the 29 possible causes,
# such as Meningitis, Alzheimer's Disease, or Cardiovascular Diseases

# examples are redundant for enumerations

@typecheck
def fn_for_cause_type(ct: CauseType) -> ...:
    # template based on enumeration (29 fields)

    if ct == CauseType.MENINGITIS:
        return ...
    elif ct == CauseType.ALZHEIMER_DISEASE_AND_DEMENTIAS:
        return ...
    elif ct == CauseType.PARKINSON:
        return ...
    elif ct == CauseType.NUTRITIONAL_DEFICIENCIES:
        return ...    
    elif ct == CauseType.MALARIA:
        return ...
    elif ct == CauseType.DROWNING:
        return ...
    elif ct == CauseType.INTERPERSONAL_VIOLENCE:
        return ...        
    elif ct == CauseType.MATERNAL_DISORDERS:
        return ...
    elif ct == CauseType.DRUG:
        return ...
    elif ct == CauseType.TUBERCULOSIS:
        return ...        
    elif ct == CauseType.CARDIOVASCULAR_DISEASES:
        return ...
    elif ct == CauseType.LOWER_RESPIRATORY_INFECTIONS:
        return ...
    elif ct == CauseType.NEONATAL_DISORDER:
        return ...    
    elif ct == CauseType.ALCOHOL_USE_DISORDERS:
        return ...
    elif ct == CauseType.SELF_HARM:
        return ...
    elif ct == CauseType.EXPOSURE_TO_FORCES_OF_NATURE:
        return ...        
    elif ct == CauseType.DIARRHEAL_DISEASES:
        return ...
    elif ct == CauseType.ENVIRONMENTAL_HEAT_AND_COLD:
        return ...
    elif ct == CauseType.NEOPLASMS:
        return ...        
    elif ct == CauseType.CONFLICT_AND_TERRORISM:
        return ...
    elif ct == CauseType.DIABETES_MELLITUS:
        return ...
    elif ct == CauseType.CHRONIC_KINDNEY_DISEASE:
        return ...    
    elif ct == CauseType.POISONINGS:
        return ...
    elif ct == CauseType.PROTEIN_ENERGY_MALNUTRITIONI:
        return ...        
    elif ct == CauseType.CHRONIC_RESPIRATORY:
        return ...
    elif ct == CauseType.CIRRHOOSIS_AND_OTHER_CHRONIC_IVER_DISEASES:
        return ...
    elif ct == CauseType.DIGESTIVE_DISEASES:
        return ...        
    elif ct == CauseType.FIRE_HEAT_HOT:
        return ...
    elif ct == CauseType.ACUTE_HEPATITIS:
        return ...

    
    
CauseData = NamedTuple("CauseData", [("type", CauseType),
                                    ("year", int), # in range [1990, 2019]
                                    ("mortality", int)]) # in range [0, ...)
# interp. the data about a type of cause of death around the world, year that reported, and the number of mortality

CD1 = CauseData(CauseType.MENINGITIS, 1990, 107)
CD2 = CauseData(CauseType.ACUTE_HEPATITIS, 2019, 1940)

@typecheck
def fn_for_cause_data(cd: CauseData) -> ...:
    # template based on compound (2 fields) and reference rule
    return ...(fn_for_cause_type(cd.type),
               cd.year,
               cd.mortality)


CauseDataList = List[CauseData]
# interp. a list of casue data

CDL0 = []
CDL1 = [CD1, CD2]
CDL2 = [CauseData(CauseType.MENINGITIS, 1990, 107), 
        CauseData(CauseType.ACUTE_HEPATITIS, 2019, 1940),
        CauseData(CauseType.MENINGITIS, 2019, 444),
        CauseData(CauseType.FIRE_HEAT_HOT, 2019, 32),
        CauseData(CauseType.NEOPLASMS, 2019, 765),
        CauseData(CauseType.DRUG, 2019, 907),
        CauseData(CauseType.DROWNING, 2019, 2),
        CauseData(CauseType.ACUTE_HEPATITIS, 2019, 54)]

@typecheck
def fn_for_cause_data_list(cdl: CauseDataList) -> ...:
    # template based on arbitrary-sized data and reference rule
    # description of the accumulator
    acc = ...   # type: ...

    for cd in cdl:
        acc = ...(fn_for_cause_data(cd), acc)

    return ...(acc)

```

### Step 2b: Reading
#### Design a function to read the information and store it as data in your program


```python
# Put your read function here!
# You can also put the read function in the cell for step 2c but this may cause your cell to become very long

###########
# Functions

@typecheck
def read(filename: str) -> CauseDataList:
    """    
    reads information from the specified file and returns a list of cause of deaths data.
    """
    #return []  #stub
    # Template from HtDAP
    # cdl contains the result so far
    cdl = [] # type: CauseDataList

    with open(filename) as csvfile:
        
        reader = csv.reader(csvfile)
        header = next(reader) 

        for row in reader:
            # you may not need to store all the rows, and you may need
            # to convert some of the strings to other types
            
            year = parse_int(row[2])
            
            # Loop through each cause column starting from index 3
            for i in range(3, len(row)):
                cause_name = header[i]
                cause_type = parse_cause_type(cause_name)
                mortality = parse_int(row[i])

                cd = CauseData(cause_type, year, mortality)
                cdl.append(cd)
                
    return cdl


@typecheck
def parse_cause_type(s: str) -> CauseType:
    """
    Given a string representing a cause of death, returns the corresponding CauseType.
    When there is an undefined value, it represents the unknown.
    """
#    return s # stub
# template based on 
    if s == "Meningitis":
        return CauseType.MENINGITIS
    elif s == "Alzheimer's Disease and Other Dementias":
        return CauseType.ALZHEIMER_DISEASE_AND_DEMENTIAS
    elif s == "Parkinson's Disease":
        return CauseType.PARKINSON
    elif s == "Nutritional Deficiencies":
        return CauseType.NUTRITIONAL_DEFICIENCIES
    elif s == "Malaria":
        return CauseType.MALARIA
    elif s == "Drowning":
        return CauseType.DROWNING
    elif s == "Interpersonal Violence":
        return CauseType.INTERPERSONAL_VIOLENCE
    elif s == "Maternal Disorders":
        return CauseType.MATERNAL_DISORDERS
    elif s == "Drug Use Disorders":
        return CauseType.DRUG
    elif s == "Tuberculosis":
        return CauseType.TUBERCULOSIS
    elif s == "Cardiovascular Diseases":
        return CauseType.CARDIOVASCULAR_DISEASES
    elif s == "Lower Respiratory Infections":
        return CauseType.LOWER_RESPIRATORY_INFECTIONS
    elif s == "Neonatal Disorders":
        return CauseType.NEONATAL_DISORDER
    elif s == "Alcohol Use Disorders":
        return CauseType.ALCOHOL_USE_DISORDERS
    elif s == "Self-harm":
        return CauseType.SELF_HARM
    elif s == "Exposure to Forces of Nature":
        return CauseType.EXPOSURE_TO_FORCES_OF_NATURE
    elif s == "Diarrheal Diseases":
        return CauseType.DIARRHEAL_DISEASES
    elif s == "Environmental Heat and Cold Exposure":
        return CauseType.ENVIRONMENTAL_HEAT_AND_COLD
    elif s == "Neoplasms":
        return CauseType.NEOPLASMS
    elif s == "Conflict and Terrorism":
        return CauseType.CONFLICT_AND_TERRORISM
    elif s == "Diabetes Mellitus":
        return CauseType.DIABETES_MELLITUS
    elif s == "Chronic Kidney Disease":
        return CauseType.CHRONIC_KINDNEY_DISEASE
    elif s == "Poisonings":
        return CauseType.POISONINGS
    elif s == "Protein-Energy Malnutrition":
        return CauseType.PROTEIN_ENERGY_MALNUTRITIONI
    elif s == "Chronic Respiratory Diseases":
        return CauseType.CHRONIC_RESPIRATORY
    elif s == "Cirrhosis and Other Chronic Liver Diseases":
        return CauseType.CIRRHOOSIS_AND_OTHER_CHRONIC_IVER_DISEASES
    elif s == "Digestive Diseases":
        return CauseType.DIGESTIVE_DISEASES
    elif s == "Fire, Heat, and Hot Substances":
        return CauseType.FIRE_HEAT_HOT
    elif s == "Acute Hepatitis":
        return CauseType.ACUTE_HEPATITIS
    else:
        return CauseType.UNKNOWN
    


# Begin testing
start_testing()

# Examples and tests for read
expect(read("cause_of_deaths_test0.csv"), [])
expect(read("cause_of_deaths_test1.csv"), [
    CauseData(CauseType.MENINGITIS, 1990, 2159),
    CauseData(CauseType.ALZHEIMER_DISEASE_AND_DEMENTIAS, 1990, 1116),
    CauseData(CauseType.PARKINSON, 1990, 371),
    CauseData(CauseType.NUTRITIONAL_DEFICIENCIES, 1990, 2087),
    CauseData(CauseType.MALARIA, 1990, 93),
    CauseData(CauseType.DROWNING, 1990, 1370),
    CauseData(CauseType.INTERPERSONAL_VIOLENCE, 1990, 1538),
    CauseData(CauseType.MATERNAL_DISORDERS, 1990, 2655),
    CauseData(CauseType.UNKNOWN, 1990, 34),
    CauseData(CauseType.DRUG, 1990, 93),
    CauseData(CauseType.TUBERCULOSIS, 1990, 4661),
    CauseData(CauseType.CARDIOVASCULAR_DISEASES, 1990, 44899),
    CauseData(CauseType.LOWER_RESPIRATORY_INFECTIONS, 1990, 23741),
    CauseData(CauseType.NEONATAL_DISORDER, 1990, 15612),
    CauseData(CauseType.ALCOHOL_USE_DISORDERS, 1990, 72),
    CauseData(CauseType.SELF_HARM, 1990, 696),
    CauseData(CauseType.EXPOSURE_TO_FORCES_OF_NATURE, 1990, 0),
    CauseData(CauseType.DIARRHEAL_DISEASES, 1990, 4235),
    CauseData(CauseType.ENVIRONMENTAL_HEAT_AND_COLD, 1990, 175),
    CauseData(CauseType.NEOPLASMS, 1990, 11580),
    CauseData(CauseType.CONFLICT_AND_TERRORISM, 1990, 1490),
    CauseData(CauseType.DIABETES_MELLITUS, 1990, 2108),
    CauseData(CauseType.CHRONIC_KINDNEY_DISEASE, 1990, 3709),
    CauseData(CauseType.POISONINGS, 1990, 338),
    CauseData(CauseType.PROTEIN_ENERGY_MALNUTRITIONI, 1990, 2054),
    CauseData(CauseType.UNKNOWN, 1990, 4154),
    CauseData(CauseType.CHRONIC_RESPIRATORY, 1990, 5945),
    CauseData(CauseType.CIRRHOOSIS_AND_OTHER_CHRONIC_IVER_DISEASES, 1990, 2673),
    CauseData(CauseType.DIGESTIVE_DISEASES, 1990, 5005),
    CauseData(CauseType.FIRE_HEAT_HOT, 1990, 323),
    CauseData(CauseType.ACUTE_HEPATITIS, 1990, 2985),
    CauseData(CauseType.MENINGITIS, 1991, 1),
    CauseData(CauseType.ALZHEIMER_DISEASE_AND_DEMENTIAS, 1991, 3),
    CauseData(CauseType.PARKINSON, 1991, 2),
    CauseData(CauseType.NUTRITIONAL_DEFICIENCIES, 1991, 2),
    CauseData(CauseType.MALARIA, 1991, 0),
    CauseData(CauseType.DROWNING, 1991, 4),
    CauseData(CauseType.INTERPERSONAL_VIOLENCE, 1991, 3),
    CauseData(CauseType.MATERNAL_DISORDERS, 1991, 1),
    CauseData(CauseType.UNKNOWN, 1991, 0),
    CauseData(CauseType.DRUG, 1991, 0),
    CauseData(CauseType.TUBERCULOSIS, 1991, 1),
    CauseData(CauseType.CARDIOVASCULAR_DISEASES, 1991, 69),
    CauseData(CauseType.LOWER_RESPIRATORY_INFECTIONS, 1991, 10),
    CauseData(CauseType.NEONATAL_DISORDER, 1991, 12),
    CauseData(CauseType.ALCOHOL_USE_DISORDERS, 1991, 0),
    CauseData(CauseType.SELF_HARM, 1991, 3),
    CauseData(CauseType.EXPOSURE_TO_FORCES_OF_NATURE, 1991, 0),
    CauseData(CauseType.DIARRHEAL_DISEASES, 1991, 3),
    CauseData(CauseType.ENVIRONMENTAL_HEAT_AND_COLD, 1991, 1),
    CauseData(CauseType.NEOPLASMS, 1991, 32),
    CauseData(CauseType.CONFLICT_AND_TERRORISM, 1991, 0),
    CauseData(CauseType.DIABETES_MELLITUS, 1991, 17),
    CauseData(CauseType.CHRONIC_KINDNEY_DISEASE, 1991, 9),
    CauseData(CauseType.POISONINGS, 1991, 0),
    CauseData(CauseType.PROTEIN_ENERGY_MALNUTRITIONI, 1991, 2),
    CauseData(CauseType.UNKNOWN, 1991, 6),
    CauseData(CauseType.CHRONIC_RESPIRATORY, 1991, 17),
    CauseData(CauseType.CIRRHOOSIS_AND_OTHER_CHRONIC_IVER_DISEASES, 1991, 5),
    CauseData(CauseType.DIGESTIVE_DISEASES, 1991, 9),
    CauseData(CauseType.FIRE_HEAT_HOT, 1991, 0),
    CauseData(CauseType.ACUTE_HEPATITIS, 1991, 0)])

summary()

start_testing()

# test for parse_cause_type
expect(parse_cause_type("Acute Hepatitis"), CauseType.ACUTE_HEPATITIS)
expect(parse_cause_type("Poisonings"), CauseType.POISONINGS)
expect(parse_cause_type("Drug Use Disorders"), CauseType.DRUG)


# show testing summary
summary()
```

    [92m2 of 2 tests passed[0m
    [92m3 of 3 tests passed[0m


### Step 2c: Building
Complete these steps in the code cell below. You will likely want to rename the analyze function so that the function name describes what your analysis function does.

Unless approved by your project TA, you **cannot** use libraries such as `numpy` or `pandas`. The project is meant as a way for you to demonstrate your knowledge of the learning goals in this course. While it is convinent to use external libraries, it will do all the work and will not help us gauge your mastery of the concepts.

You also cannot use built in list functions (e.g., `sum` or `average`) when writing code to do your substantial computation. Normally we encourage you to make use of what is already available but in this case, the final project involves demonstrating skills from class (e.g., how to work with a list). Using pre-built functions for this does not enable you to demonstrate what you know.

If you wish to change your project idea, you must **first** obtain permission from your TA. When contacting your TA, please provide a valid reason for why you want to change your project. Each time you change your topic idea, your TA will have to evaluate it to see if it will meet all of the project requirements. This is non-trivial task during one of the busiest times of the semester. As such, the deadline for project idea changes will be 3 business days before the deadline. Note that the deliverable deadline will not be extended and there is no compensation for the time you spent on the previous idea.

You are welcome to use the Worked Examples from module 8 as a basis for your final project. However, please do make sure you cite the lines of code that you did not write. For example, it is fine to copy/paste the `produce_num_sequence` function from the Module 8 Bar Chart Worked Example. All you need to do is leave a comment above the function that says something like `# lines x to y were copied from the module 8 bar chart worked example`. Lines of code that you did not write are not eligble for grading consideration but are expected to adhere to the principles of code discussed in class (e.g., naming conventions).


```python
###########
# Functions
import matplotlib.pyplot as pyplot
from typing import List, Tuple

@typecheck
def main(filename: str) -> None:
    """
    Reads the file from the given filename and produces a bar graph showing the top 5 of the average deaths for each type of cause. 
    """
#   return None # stub
    # Template from HtDAP, based on function composition 
    return plot_bar_chart(read(filename)) 
    


@typecheck
def plot_bar_chart(cdl: CauseDataList) -> None: 
    """ 
    Plots the number of deaths in cause_of_death from cdl.
    
    The graph title should be "The Top 5 of The Cause of Death vs The Average Number of Death (1990 - 2019)".
    The x-axis is labeled "The Cause of Death" while the y-axis is labeled "The Average Number of Death".
    """ 

#    return None # stub

    # Template based on visualization

    # the width of each bar
    bar_width = 7
    
    # the height of bar
    means =  top_5_average(find_average(cdl))
    
    average_values = extract_averages(means)

    # the middle coordinate for each of the bars for the bar chart
    middle_of_bars = produce_num_sequence(average_values, 5, bar_width + 1)

    # the opacity for the bars. It must be between 0 and 1, and higher numbers are more opaque (darker)
    opacity = 0.8

    # create the first bar chart
    rects1 = pyplot.bar(middle_of_bars, 
                     average_values,                       # list containing the height for each bar, here the average_values
                     bar_width,
                     alpha=opacity,                 # set the opacity
                     color='b')                     # set the colour (here, blue)

    # set the labels for the x-axis, y-axis, and plot title
    pyplot.xlabel('The Cause of Death')
    pyplot.ylabel('The Average Number of Death')
    pyplot.title('The Top 5 of The Cause of Death vs The Average Number of Death (1990 - 2019)')

    # set the x-coordinate for positioning the labels. Here, we want each label to be in the middle of each bar
    x_coord_labels = middle_of_bars

    # set the labels for each 'tick' on the x-axis
    tick_labels = generate_x_labels(means)

    pyplot.xticks(x_coord_labels, tick_labels, rotation = 70)

    # show the plot
    pyplot.show()

    return


@typecheck
def total_mortality(cdl: CauseDataList, target_cause: CauseType) -> int:
    """
    Given the type of cause, return to the sum of mortality.
    """
    
#     return 0 # stub
#   template based on CauseDataList and additional parameter (CauseType)
    # total contains the result so far
    total = 0   # type: int
    
    for cd in cdl:
        if cd.type == target_cause:
            total += cd.mortality
            
    return total
    
    
@typecheck
def number_of_case(cdl: CauseDataList, target_cause: CauseType) -> int:
    """
    Return to the number of case that was reported to casue of death.
    """
#   return 0 # stub
    # template based on CauseDataList and additional parameter (CauseType)
    # count contains the result so far
    count = 0
    
    for cd in cdl:
        if cd.type == target_cause:
            count += 1
            
    return count

    
@typecheck
def find_average(cdl: CauseDataList) -> List[tuple]:
    """
    Make a list of the average number of mortality per each cause.
    The order will be the same as the file we read.
    """
#   return [] # stub
    # template based on CauseDataList
    # averages contains the result so far
    averages = []   # type: List[tuple]
    
    cause_data = []
    
    for cd in cdl:
        target_cause = cd.type
        if target_cause not in cause_data:
            total_mort = total_mortality(cdl, target_cause)
            count = number_of_case(cdl, target_cause)
            
            if count > 0:
                avg = total_mort / count
                averages.append((target_cause, avg))
                
            cause_data.append(target_cause)
            
    return averages


@typecheck
def top_5_average(avg: List[tuple]) -> List[tuple]:
    """
    Make a list of the top 5 average numbers of mortality per cause.
    The order will be from the most to the least.
    """
#   return [] # stub
    # template based on List[tuple]
    
    n = len(avg)
    
    for i in range(n):
        for j in range(0, n-i-1):
            cause1, avg1 = avg[j]
            cause2, avg2 = avg[j+1]
            
            if avg1 < avg2:
                avg[j], avg[j+1] = avg[j+1],  avg[j]

    return avg[:5]

@typecheck
def extract_averages(avg: List[tuple]) -> List[float]:
    """
    Given a list of (cause, average) tuples, return a list of average values (the second element).
    The order will be from the most to the least.
    """
#     return [] # stub
#   template based on List[tuple]
#   averages contains the result so far
    averages = [] # type: List[float]
    
    for _, average in avg:
        averages.append(average)
        
    return averages
        
# lines 168 to 191 were copied from the module 8 bar chart worked example.
@typecheck
def produce_num_sequence(values: List[float], initial: float, gap: float) -> List[float]:
    """
    Produce a list of numbers like [initial, initial + gap, initial + 2*gap, ...] of the same
    length as values, e.g., to give alignment coordinates for a plot. The number
    of numbers in the list is equal to len(values). The first value is initial. The gap between values
    is gap.

    E.g., [5,15,25,35,45,55,65,75] for 8 values, initial == 5, and gap == 10.
    """
    #return []  #stub
    # Template from FloatList with two additional parameters

    # nums is the numbers for the values seen so far
    nums = []  # type: IntList

    # next_num is the next number to use
    next_num = initial

    for val in values:
        nums.append(next_num)
        next_num = next_num + gap

    return nums


@typecheck
def generate_x_labels(avg: List[tuple]) -> List[str]:
    """
    Given a list of (cause, average) tuples, return the list of causes to be used as x-axis labels.
    """

#     return [] # stub
#   labels contains the result so far
    labels = []
    for cause, _ in avg:
        clean_cause = str(cause)[10:]
        labels.append(str(clean_cause))
        
    return labels


########################################################################
# Examples and tests for main
########################################################################
start_testing()

expect(main("cause_of_deaths_test0.csv"),None)

expect(main("cause_of_deaths_test1.csv"),None)

summary()

##############################
# Examples and tests for read
##############################
start_testing()

expect(read("cause_of_deaths_test0.csv"), [])

expect(read("cause_of_deaths_test1.csv"), [CauseData(CauseType.MENINGITIS, 1990, 2159), CauseData(CauseType.ALZHEIMER_DISEASE_AND_DEMENTIAS, 1990, 1116), 
                                           CauseData(CauseType.PARKINSON, 1990, 371), CauseData(CauseType.NUTRITIONAL_DEFICIENCIES, 1990, 2087), CauseData(CauseType.MALARIA, 1990, 93), 
                                           CauseData(CauseType.DROWNING, 1990, 1370), CauseData(CauseType.INTERPERSONAL_VIOLENCE, 1990, 1538), CauseData(CauseType.MATERNAL_DISORDERS, 1990, 2655), 
                                           CauseData(CauseType.UNKNOWN,1990, 34), CauseData(CauseType.DRUG, 1990, 93), CauseData(CauseType.TUBERCULOSIS, 1990, 4661), CauseData(CauseType.CARDIOVASCULAR_DISEASES, 1990, 44899), 
                                           CauseData(CauseType.LOWER_RESPIRATORY_INFECTIONS, 1990, 23741), CauseData(CauseType.NEONATAL_DISORDER, 1990, 15612), CauseData(CauseType.ALCOHOL_USE_DISORDERS, 1990, 72), 
                                           CauseData(CauseType.SELF_HARM, 1990, 696), CauseData(CauseType.EXPOSURE_TO_FORCES_OF_NATURE, 1990, 0), CauseData(CauseType.DIARRHEAL_DISEASES, 1990, 4235), 
                                           CauseData(CauseType.ENVIRONMENTAL_HEAT_AND_COLD, 1990, 175), CauseData(CauseType.NEOPLASMS, 1990, 11580), CauseData(CauseType.CONFLICT_AND_TERRORISM, 1990, 1490), 
                                           CauseData(CauseType.DIABETES_MELLITUS, 1990, 2108), CauseData(CauseType.CHRONIC_KINDNEY_DISEASE, 1990, 3709), CauseData(CauseType.POISONINGS, 1990, 338), 
                                           CauseData(CauseType.PROTEIN_ENERGY_MALNUTRITIONI, 1990, 2054), CauseData(CauseType.UNKNOWN, 1990, 4154), CauseData(CauseType.CHRONIC_RESPIRATORY, 1990, 5945), 
                                           CauseData(CauseType.CIRRHOOSIS_AND_OTHER_CHRONIC_IVER_DISEASES, 1990, 2673), CauseData(CauseType.DIGESTIVE_DISEASES, 1990, 5005), 
                                           CauseData(CauseType.FIRE_HEAT_HOT, 1990, 323), CauseData(CauseType.ACUTE_HEPATITIS, 1990, 2985), CauseData(CauseType.MENINGITIS, 1991, 1), 
                                           CauseData(CauseType.ALZHEIMER_DISEASE_AND_DEMENTIAS, 1991, 3), CauseData(CauseType.PARKINSON, 1991,2), CauseData(CauseType.NUTRITIONAL_DEFICIENCIES, 1991, 2), 
                                           CauseData(CauseType.MALARIA, 1991, 0), CauseData(CauseType.DROWNING, 1991, 4), CauseData(CauseType.INTERPERSONAL_VIOLENCE, 1991, 3), CauseData(CauseType.MATERNAL_DISORDERS, 1991, 1), 
                                           CauseData(CauseType.UNKNOWN, 1991, 0), CauseData(CauseType.DRUG, 1991, 0), CauseData(CauseType.TUBERCULOSIS, 1991, 1), CauseData(CauseType.CARDIOVASCULAR_DISEASES, 1991, 69), 
                                           CauseData(CauseType.LOWER_RESPIRATORY_INFECTIONS,1991, 10), CauseData(CauseType.NEONATAL_DISORDER, 1991, 12), CauseData(CauseType.ALCOHOL_USE_DISORDERS, 1991, 0), 
                                           CauseData(CauseType.SELF_HARM, 1991, 3), CauseData(CauseType.EXPOSURE_TO_FORCES_OF_NATURE, 1991, 0), CauseData(CauseType.DIARRHEAL_DISEASES, 1991, 3), 
                                           CauseData(CauseType.ENVIRONMENTAL_HEAT_AND_COLD, 1991, 1), CauseData(CauseType.NEOPLASMS, 1991, 32), CauseData(CauseType.CONFLICT_AND_TERRORISM, 1991, 0), 
                                           CauseData(CauseType.DIABETES_MELLITUS, 1991, 17), CauseData(CauseType.CHRONIC_KINDNEY_DISEASE, 1991, 9), CauseData(CauseType.POISONINGS, 1991, 0), 
                                           CauseData(CauseType.PROTEIN_ENERGY_MALNUTRITIONI, 1991, 2), CauseData(CauseType.UNKNOWN, 1991, 6), CauseData(CauseType.CHRONIC_RESPIRATORY, 1991, 17), 
                                           CauseData(CauseType.CIRRHOOSIS_AND_OTHER_CHRONIC_IVER_DISEASES, 1991, 5), CauseData(CauseType.DIGESTIVE_DISEASES, 1991, 9), CauseData(CauseType.FIRE_HEAT_HOT, 1991, 0), 
                                           CauseData(CauseType.ACUTE_HEPATITIS, 1991, 0)])

summary()

# Examples and tests for analyze 
########################
# test total_mortality
########################
start_testing()

expect(total_mortality(CDL0, CauseType.MENINGITIS), 0) 
expect(total_mortality(CDL1, CauseType.MENINGITIS), 107) 
expect(total_mortality(CDL1, CauseType.ACUTE_HEPATITIS), 1940) 
expect(total_mortality(CDL2, CauseType.ACUTE_HEPATITIS), 1994) 
expect(total_mortality(CDL2, CauseType.MENINGITIS), 551) 
expect(total_mortality(CDL2, CauseType.DRUG), 907) 

expect(total_mortality([CauseData(CauseType.MENINGITIS, 1990, 2159), CauseData(CauseType.MENINGITIS,2010, 8970)], CauseType.MENINGITIS), 11129)


summary()

#######################
# test number_of_case
#######################

start_testing()

expect(number_of_case(CDL0, CauseType.MENINGITIS), 0) 
expect(number_of_case(CDL1, CauseType.MENINGITIS), 1) 
expect(number_of_case(CDL1, CauseType.ACUTE_HEPATITIS), 1) 
expect(number_of_case(CDL2, CauseType.MENINGITIS), 2) 
expect(number_of_case(CDL2, CauseType.ACUTE_HEPATITIS), 2) 
expect(number_of_case(CDL2, CauseType.DRUG), 1) 

expect(number_of_case([CauseData(CauseType.MENINGITIS, 1990, 2159), CauseData(CauseType.MENINGITIS,2010, 8970)], CauseType.MENINGITIS), 2)

summary()

####################
# test find_average
####################

start_testing()

expect(find_average(CDL0), [])
expect(find_average(CDL1), [(CauseType.MENINGITIS, 107.0), (CauseType.ACUTE_HEPATITIS, 1940.0)])
expect(find_average(CDL2), [(CauseType.MENINGITIS, 275.5), (CauseType.ACUTE_HEPATITIS, 997.0), (CauseType.FIRE_HEAT_HOT, 32.0), (CauseType.NEOPLASMS, 765.0), (CauseType.DRUG, 907.0), (CauseType.DROWNING, 2.0)])

expect(find_average([CauseData(CauseType.MENINGITIS, 1990, 2159), CauseData(CauseType.MENINGITIS,2010, 8970)]), [(CauseType.MENINGITIS, 5564.5)])

summary()

#####################
# test top_5_average
#####################

start_testing()

expect(top_5_average(CDL0), [])
expect(top_5_average(find_average(CDL1)), [(CauseType.ACUTE_HEPATITIS, 1940.0), (CauseType.MENINGITIS, 107.0)])
expect(top_5_average(find_average(CDL2)), [(CauseType.ACUTE_HEPATITIS, 997.0), (CauseType.DRUG, 907.0), (CauseType.NEOPLASMS, 765.0), (CauseType.MENINGITIS, 275.5), (CauseType.FIRE_HEAT_HOT, 32.0)])

expect(top_5_average(find_average([CauseData(CauseType.MENINGITIS, 1990, 2159), CauseData(CauseType.MENINGITIS,2010, 8970)])), [(CauseType.MENINGITIS, 5564.5)])

summary()

########################
# test extract_averages
########################

start_testing()

expect(extract_averages(CDL0), [])
expect(extract_averages(top_5_average(find_average(CDL1))),[1940.0, 107.0])
expect(extract_averages(top_5_average(find_average(CDL2))),[997.0, 907.0, 765.0, 275.5, 32.0])

summary()

###########################
# test produce_num_sequence
###########################

start_testing()

expect(produce_num_sequence([], 5, 10), [])
expect(produce_num_sequence([1940.0, 107.0], 5, 10), [5, 15])
expect(produce_num_sequence([997.0, 907.0, 765.0, 275.5, 32.0], 0.5, 3), [0.5, 3.5, 6.5,9.5,12.5])

summary()

######################## 
# test generate_x_labels
########################

start_testing()

expect(generate_x_labels(top_5_average(CDL0)), [])
expect(generate_x_labels(top_5_average(find_average(CDL1))), ["ACUTE_HEPATITIS", "MENINGITIS"])
expect(generate_x_labels(top_5_average(find_average(CDL2))), ["ACUTE_HEPATITIS", "DRUG", "NEOPLASMS", "MENINGITIS", "FIRE_HEAT_HOT"])

summary()
```


    
![png](output_14_0.png)
    



    
![png](output_14_1.png)
    


    [92m2 of 2 tests passed[0m
    [92m2 of 2 tests passed[0m
    [92m7 of 7 tests passed[0m
    [92m7 of 7 tests passed[0m
    [92m4 of 4 tests passed[0m
    [92m4 of 4 tests passed[0m
    [92m3 of 3 tests passed[0m
    [92m3 of 3 tests passed[0m
    [92m3 of 3 tests passed[0m


### Final Graph/Chart

Now that everything is working, you **must** call `main` on the intended information source in order to display the final graph/chart:


```python
main("cause_of_deaths.csv")
```


    
![png](output_16_0.png)
    


# <font color="red">Be sure to save in Jupyter AND PrairieLearn</font>
Failure to save in either spot will mean that your work will not be able to be graded.

If you do not save in Jupyter, no one will be able to see the code that you wrote.

If you do not click the "Save" button in PrairieLearn, your work will not appear in the grading queue. We reserve the right to award a zero to submissions that are not subitted through the specified avenue.


```python

```
